package com.example.androidspinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    // Initialize your spinner Variables
    private Spinner spinnerTextSize;
    private TextView textViewHelloWorld;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Reference the id's of your spinner and text
        spinnerTextSize = findViewById(R.id.spinner);
        textViewHelloWorld = findViewById(R.id.helloWordText);

        // This Adapter Settings Enable Your Spinner to work as a spinner
        spinnerTextSize.setOnItemSelectedListener(this);
        String[] textSizes = getResources().getStringArray(R.array.font_sizes);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
                textSizes);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinnerTextSize.setAdapter(adapter);
    }

    // Remember spinner is used as a drop down as you see in NavBar dropdown on a website
    // Your EditText can take in the input.
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        // if spinner is clicked then what should happened.
        if (parent.getId() == R.id.spinner){
            // Then execute your function here
            String valueFromSpinner = parent.getItemAtPosition(position).toString();
            textViewHelloWorld.setTextSize(Float.parseFloat(valueFromSpinner));
        }
    }

    // If nothing is selected then nothing happened
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}